package org.firstinspires.ftc.teamcode.subsystems.subsubsystems;

import com.arcrobotics.ftclib.hardware.motors.Motor;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.arcrobotics.ftclib.hardware.motors.MotorEx;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp
public class Drone extends OpMode {
    public Servo servo2;
    @Override
    public void init() {
        servo2 = hardwareMap.get(Servo.class, "drone");
    }
    @Override
    public void loop() {

        boolean DPADPressed = false;
        servo2.resetDeviceConfigurationForOpMode();
        servo2.getPosition();
        while (DPADPressed = false) {
            servo2.setPosition(0);

        }
            servo2.setPosition(0);
        if (gamepad2.dpad_left) {

            DPADPressed = true;
            servo2.setPosition(1);
            try {
                Thread.sleep(250);
            } catch (InterruptedException e) {
               telemetry.addData("Oops " , "Took too long!");
            }
            servo2.setPosition(-1);
            try {
                Thread.sleep(250);
            } catch (InterruptedException e) {
                telemetry.addData("Oops " , "Took too long!");
            }
            servo2.setPosition(0);

        }
        servo2.setPosition(0);
    }

}
