package org.firstinspires.ftc.teamcode;

public class Variables { // static data stored in here is saved between autonomous and teleop

    public static double max_speed = 0.5;

    public static boolean teleOp = false;
}